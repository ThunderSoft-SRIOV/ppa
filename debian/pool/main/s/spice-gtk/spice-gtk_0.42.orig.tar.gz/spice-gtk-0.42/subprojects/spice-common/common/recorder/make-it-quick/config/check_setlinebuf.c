#include <stdio.h>

int main()
{
    FILE *f = stdout;
    setlinebuf(f);
}
